﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._14___Date
{
    class Program
    {
        static void Main(string[] args)
        {
            Date MyDate = new _14___Date.Date(5, 7, 27);
            MyDate.DisplayDate();
        }
    }
}
